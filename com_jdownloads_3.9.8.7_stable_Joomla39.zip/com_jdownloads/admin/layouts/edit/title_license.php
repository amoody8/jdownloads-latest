<?php
defined('JPATH_BASE') or die;

$options = $this->options;
$form = $displayData->getForm();

?>
<div class="form-inline form-inline-header">
	<?php
	    echo $form->renderField('title');
    ?>
</div>
