<?php
/**
 * @package jDownloads
 * @version 4.0  
 * @copyright (C) 2007 - 2016 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */
 
defined('_JEXEC') or die('Restricted access');

if (!defined('DS')){
   define('DS',DIRECTORY_SEPARATOR);
} 

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

// This extension does only work with Joomla release 3.9 or 3.10 - otherwise abort
$jversion     = new JVersion;
$jversion_value = substr($jversion->getShortVersion(), 0, 4);

if (!version_compare($jversion_value, '3.10', '<=')){
    // Is not the required joomla version 3.x - Abort!
    Factory::getApplication()->enqueueMessage( Text::_('This jDownloads version is not compatible with Joomla 4.x. Please install the update!'), 'error');
    return false;
}

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_jdownloads')) {
    return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';
require_once JPATH_COMPONENT.DS.'helpers'.DS.'jdownloads.php';

jimport('joomla.application.component.controller');

// Get an instance of the controller
$controller = JControllerLegacy::getInstance('jdownloads');
 
// Perform the Request task
$jinput = JFactory::getApplication()->input;
$controller->execute($jinput->get('task'));
 
// Redirect if set by the controller
$controller->redirect();

if (!$jinput->getString('layout') == 'modal' && !$jinput->getString('layout') == 'modallist'){
    $footer = JDownloadsHelper::buildBackendFooterText('center');
} else {
    $footer = '';
}
echo $footer;
                   

?>