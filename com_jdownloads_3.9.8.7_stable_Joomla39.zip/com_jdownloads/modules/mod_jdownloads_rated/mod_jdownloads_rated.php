<?php
/**
* @version $Id: mod_jdownloads_rated.php v3.8
* @package mod_jdownloads_rated
* @copyright (C) 2018 Arno Betz
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author Arno Betz http://www.jDownloads.com
*
* This module shows you the most-rated or top-rated downloads from the jDownloads component. It is only for jDownloads 3.9 and later
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

    require_once __DIR__ . '/helper.php';
    
    require_once( JPATH_ROOT . DS . 'components' . DS . 'com_jdownloads' . DS . 'helpers' . DS .'jdownloads.php' );

    $db = JFactory::getDBO();
    $Itemid  = JRequest::getVar("Itemid");
    
    // get published root menu link
    $db->setQuery("SELECT id from #__menu WHERE link = 'index.php?option=com_jdownloads&view=categories' and published = 1 AND client_id = 0");
    $root_itemid = $db->loadResult();
    
    if ($root_itemid){
        $Itemid = $root_itemid;
    }
    //add style sheet
    $document = JFactory::getDocument();
	$document->addStyleSheet( JURI::base()."components/com_jdownloads/assets/css/jdownloads_modules.css", 'text/css', null, array() );
    // get this option from configuration to see whether the links shall run the download without summary page
    $app = JFactory::getApplication();
	$jdparams = $app->getParams('com_jdownloads');
	$direct_download_config = $jdparams->get('direct_download');
	$detail_view_config = $jdparams->get('view_detailsite');
	
	$image_dir = JURI::root().'modules/'.$module->module.'/mod_jdownloads_images/';
    
    $top_view              = $params->get( 'top_view' );
    $before                = trim($params->get( 'text_before' ) );
    $text_before           = ModJDownloadsRatedHelper::getOnlyLanguageSubstring($before);
    $after                 = trim($params->get( 'text_after' ) );
    $text_after            = ModJDownloadsRatedHelper::getOnlyLanguageSubstring($after);
    $catid                 = $params->get('catid', array()); 
    $sum_view              = intval($params->get( 'sum_view' ));
    $sum_char              = intval($params->get( 'sum_char' ));
    $short_char            = $params->get( 'short_char', '' ) ; 
    $short_version         = $params->get( 'short_version', '' );
    $detail_view           = $params->get( 'detail_view' ) ;
    $view_date             = intval($params->get( 'view_date') ) ;
    $view_date_same_line   = intval($params->get( 'view_date_same_line') );
	$view_date_label        = $params->get( 'view_date_label' );
    $view_date_label        = modJdownloadsRatedHelper::getOnlyLanguageSubstring($view_date_label);	
    // We use the standard short date format from the activated language when here is not a format defined 
    $date_format           = $params->get( 'date_format', JText::_('DATE_FORMAT_LC4') );
	$view_hits             = intval($params->get( 'view_hits' ) );
    $view_hits_same_line   = intval($params->get( 'view_hits_same_line' ));
    $view_hits_label       = $params->get( 'view_hits_label' );
	$view_hits_label       = modJdownloadsRatedHelper::getOnlyLanguageSubstring($view_hits_label);	
    $view_pics             = intval($params->get( 'view_pics' ));
	$view_pics_link        = intval($params->get( 'view_pics_link' ));
    $view_pics_size        = intval($params->get( 'view_pics_size' )) ;
    $view_numerical_list   = intval($params->get( 'view_numerical_list' ));
    $view_stars            = intval($params->get( 'view_stars' ) );
    $view_stars_same_line   = intval($params->get( 'view_stars_same_line' ) );
	$view_votes            = intval($params->get( 'view_votes' ) );
    $view_stars_votes_same_line  = intval($params->get( 'view_stars_votes_same_line' ) );
    $alignment             = $params->get( 'alignment' );
    $moduleclass_sfx       = htmlspecialchars($params->get('moduleclass_sfx'));

    $view_date_label = trim($view_date_label);
	if ($view_date_label) $view_date_label = $view_date_label.' ';
	$view_hits_label = trim($view_hits_label);
	if ($view_hits_label) $view_hits_label = $view_hits_label.' ';
	
	
    if ($sum_view == 0) $sum_view = 5;
    $option = 'com_jdownloads';
        
    $files = ModJDownloadsRatedHelper::getList($params);

    if (!count($files)) {
        return;
    }
    
    require JModuleHelper::getLayoutPath('mod_jdownloads_rated',$params->get('layout', 'default'));    
?>